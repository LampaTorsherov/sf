package objx

var TestMap = map[string]interface{}{
	"name": "Tyler",
	"address": map[string]interface{}{
		"city":  "Salt Lake City",
		"state": "UT",
	},
	"numbers": []interface{}{"one", "two", "three", "four", "five"},
}
